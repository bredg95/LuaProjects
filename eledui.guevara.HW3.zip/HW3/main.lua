-----------------------------------------------------------------------------------------
-- Homework 3 Alex the Kidd Janken
-- Members: Garrett Eledui, Branden Guevara
-- Description: 
-- File: main.lua
--
-----------------------------------------------------------------------------------------

display.setStatusBar( display.HiddenStatusBar )
local composer = require("composer");
composer.gotoScene( "startScene");