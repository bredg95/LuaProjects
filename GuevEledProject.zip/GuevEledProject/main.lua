-----------------------------------------------------------------------------------------
-- 
-- Members: Branden Guevara, Garrett Eledui
-- 
-- File: main.lua
--
-----------------------------------------------------------------------------------------

local composer = require("composer")
composer.gotoScene("mainMenu")

